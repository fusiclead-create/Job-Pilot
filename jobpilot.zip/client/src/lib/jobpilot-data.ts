export type Job = {
  id: string;
  company: string;
  initials: string;
  companyColor: string;
  title: string;
  location: string;
  mode: "Remote" | "Hybrid" | "On-site";
  country: string;
  source: string;
  posted: string;
  salary: string;
  salaryInr: string;
  sponsorship: "Confirmed" | "Likely" | "Unknown" | "No";
  score: number;
  tags: string[];
  description: string;
  recruiter?: string;
};

export type ApplicationStatus =
  | "Needs review"
  | "Preparing"
  | "Submitted"
  | "Interview"
  | "Rejected"
  | "Offer";

export type Application = {
  id: string;
  company: string;
  initials: string;
  companyColor: string;
  title: string;
  location: string;
  source: string;
  appliedDate?: string;
  postedDate: string;
  status: ApplicationStatus;
  score: number;
  followUp: string;
  resume: string;
  salary: string;
  salaryInr: string;
  sponsorship: string;
  recruiter: string;
  note: string;
  hasUnknownQuestion?: boolean;
};

export type InboxMessage = {
  id: string;
  sender: string;
  company: string;
  subject: string;
  preview: string;
  kind: "Interview" | "Recruiter" | "Assessment" | "Confirmation" | "Rejection";
  time: string;
  unread?: boolean;
};

export const jobs: Job[] = [
  {
    id: "notion-product",
    company: "Notion",
    initials: "N",
    companyColor: "#111111",
    title: "Product Designer, AI Experiences",
    location: "Remote · United States",
    mode: "Remote",
    country: "United States",
    source: "Greenhouse",
    posted: "2h ago",
    salary: "$145k – $190k",
    salaryInr: "₹1.21Cr – ₹1.59Cr",
    sponsorship: "Confirmed",
    score: 96,
    tags: ["Product design", "AI", "Figma"],
    description:
      "Shape the next generation of AI-assisted workflows across Notion. Partner with product and engineering to make complex systems feel clear, useful, and human.",
    recruiter: "Maya Chen · Talent Partner",
  },
  {
    id: "linear-senior",
    company: "Linear",
    initials: "L",
    companyColor: "#5E6AD2",
    title: "Senior Product Designer",
    location: "San Francisco · Hybrid",
    mode: "Hybrid",
    country: "United States",
    source: "Company page",
    posted: "4h ago",
    salary: "$160k – $205k",
    salaryInr: "₹1.34Cr – ₹1.72Cr",
    sponsorship: "Likely",
    score: 91,
    tags: ["Systems", "B2B", "0→1"],
    description:
      "Join the product design team building the tool that modern teams use to plan, build, and ship. You will own end-to-end product areas with a high degree of craft.",
    recruiter: "Jordan Ellis · Design Recruiting",
  },
  {
    id: "ramp-staff",
    company: "Ramp",
    initials: "R",
    companyColor: "#111827",
    title: "Staff Product Designer, Growth",
    location: "New York · On-site",
    mode: "On-site",
    country: "United States",
    source: "LinkedIn",
    posted: "Yesterday",
    salary: "$180k – $230k",
    salaryInr: "₹1.51Cr – ₹1.93Cr",
    sponsorship: "Unknown",
    score: 84,
    tags: ["Growth", "Fintech", "Leadership"],
    description:
      "Lead high-impact growth initiatives and help teams make informed product bets. This role blends strategy, experimentation, and hands-on design leadership.",
  },
  {
    id: "atlassian-lead",
    company: "Atlassian",
    initials: "A",
    companyColor: "#0C66E4",
    title: "Lead Product Designer, Platform",
    location: "Bengaluru · Hybrid",
    mode: "Hybrid",
    country: "India",
    source: "Naukri",
    posted: "Yesterday",
    salary: "₹46L – ₹64L",
    salaryInr: "₹46L – ₹64L",
    sponsorship: "No",
    score: 79,
    tags: ["Platform", "Design systems", "Mentoring"],
    description:
      "Help make Atlassian’s platform coherent and extensible across products. You will work with distributed teams and contribute to a growing design system.",
  },
  {
    id: "figma-staff",
    company: "Figma",
    initials: "F",
    companyColor: "#F24E1E",
    title: "Staff Product Designer, AI",
    location: "London · Remote-friendly",
    mode: "Remote",
    country: "United Kingdom",
    source: "Lever",
    posted: "2d ago",
    salary: "£120k – £150k",
    salaryInr: "₹1.27Cr – ₹1.59Cr",
    sponsorship: "Likely",
    score: 88,
    tags: ["AI", "Collaboration", "Systems"],
    description:
      "Design new ways for teams to create together with AI. Work across product, research, and engineering to turn emerging behaviors into trustworthy tools.",
  },
];

export const initialApplications: Application[] = [
  {
    id: "app-linear",
    company: "Linear",
    initials: "L",
    companyColor: "#5E6AD2",
    title: "Senior Product Designer",
    location: "San Francisco · Hybrid",
    source: "Company page",
    postedDate: "Sep 29, 2026",
    status: "Needs review",
    score: 91,
    followUp: "Due in 4 days",
    resume: "Senior Product Designer · v3",
    salary: "$160k – $205k",
    salaryInr: "₹1.34Cr – ₹1.72Cr",
    sponsorship: "Likely · verify before submitting",
    recruiter: "Jordan Ellis",
    note: "Two questions need confirmation before we can continue.",
    hasUnknownQuestion: true,
  },
  {
    id: "app-notion",
    company: "Notion",
    initials: "N",
    companyColor: "#111111",
    title: "Product Designer, AI Experiences",
    location: "Remote · United States",
    source: "Greenhouse",
    appliedDate: "Sep 28, 2026",
    postedDate: "Sep 30, 2026",
    status: "Interview",
    score: 96,
    followUp: "Oct 7, 2026",
    resume: "AI Product Designer · v4",
    salary: "$145k – $190k",
    salaryInr: "₹1.21Cr – ₹1.59Cr",
    sponsorship: "Confirmed",
    recruiter: "Maya Chen",
    note: "Recruiter asked for a portfolio walkthrough.",
  },
  {
    id: "app-atlassian",
    company: "Atlassian",
    initials: "A",
    companyColor: "#0C66E4",
    title: "Lead Product Designer, Platform",
    location: "Bengaluru · Hybrid",
    source: "Naukri",
    appliedDate: "Sep 24, 2026",
    postedDate: "Sep 23, 2026",
    status: "Submitted",
    score: 79,
    followUp: "Tomorrow",
    resume: "Product Design Lead · v2",
    salary: "₹46L – ₹64L",
    salaryInr: "₹46L – ₹64L",
    sponsorship: "Not required",
    recruiter: "Priya Nair",
    note: "Follow up with hiring manager after one week.",
  },
  {
    id: "app-ramp",
    company: "Ramp",
    initials: "R",
    companyColor: "#111827",
    title: "Staff Product Designer, Growth",
    location: "New York · On-site",
    source: "LinkedIn",
    appliedDate: "Sep 20, 2026",
    postedDate: "Sep 18, 2026",
    status: "Rejected",
    score: 84,
    followUp: "—",
    resume: "Growth Design · v1",
    salary: "$180k – $230k",
    salaryInr: "₹1.51Cr – ₹1.93Cr",
    sponsorship: "Unknown",
    recruiter: "Unassigned",
    note: "Role closed after shortlist.",
  },
];

export const inboxMessages: InboxMessage[] = [
  {
    id: "m1",
    sender: "Maya Chen",
    company: "Notion",
    subject: "Next step: Product Designer, AI Experiences",
    preview: "We enjoyed reviewing your work and would love to schedule a 30-minute portfolio conversation…",
    kind: "Interview",
    time: "18m ago",
    unread: true,
  },
  {
    id: "m2",
    sender: "Linear recruiting",
    company: "Linear",
    subject: "Your application has been received",
    preview: "Thanks for applying for Senior Product Designer. Our team will be in touch if there is a match…",
    kind: "Confirmation",
    time: "Yesterday",
  },
  {
    id: "m3",
    sender: "Jordan Ellis",
    company: "Linear",
    subject: "A quick question about your application",
    preview: "Could you share a little more about your experience with design systems and platform work?",
    kind: "Recruiter",
    time: "Yesterday",
    unread: true,
  },
  {
    id: "m4",
    sender: "Atlassian Talent",
    company: "Atlassian",
    subject: "Design exercise details",
    preview: "Your design exercise is ready. Please review the instructions and submit by Friday…",
    kind: "Assessment",
    time: "Sep 29",
  },
  {
    id: "m5",
    sender: "Ramp Recruiting",
    company: "Ramp",
    subject: "Update on your application",
    preview: "Thank you for the time you invested. We have decided to move ahead with other candidates…",
    kind: "Rejection",
    time: "Sep 25",
  },
];

export const recruiters = [
  { name: "Maya Chen", role: "Talent Partner", company: "Notion", email: "maya.chen@notion.so", source: "Notion team page", status: "Verified" },
  { name: "Jordan Ellis", role: "Design Recruiting", company: "Linear", email: "jordan@linear.app", source: "Linear careers", status: "Verified" },
  { name: "Priya Nair", role: "Senior Recruiter", company: "Atlassian", email: "Not publicly listed", source: "Atlassian careers", status: "Not listed" },
  { name: "Alex Morgan", role: "People Operations", company: "Figma", email: "alex.morgan@figma.com", source: "Public profile", status: "Needs review" },
];

export const sources = ["All sources", "LinkedIn", "Naukri", "Greenhouse", "Lever", "Company page"];

export const statusColors: Record<ApplicationStatus, string> = {
  "Needs review": "bg-[#FFF2CF] text-[#8A5A00]",
  Preparing: "bg-[#E8F0FF] text-[#3156A3]",
  Submitted: "bg-[#E7F7EE] text-[#147341]",
  Interview: "bg-[#E7F1FF] text-[#1D5BBF]",
  Rejected: "bg-[#FBE8E6] text-[#AE3C32]",
  Offer: "bg-[#E4F6DB] text-[#2A6B18]",
};

export const navItems = [
  { label: "Overview", href: "/", icon: "layout" },
  { label: "Job search", href: "/jobs", icon: "search" },
  { label: "Applications", href: "/applications", icon: "check" },
  { label: "Follow-up studio", href: "/follow-ups", icon: "mail" },
  { label: "Market pulse", href: "/analytics", icon: "trend" },
  { label: "Automation", href: "/automation", icon: "settings" },
  { label: "Resume studio", href: "/resume", icon: "file" },
  { label: "Career profile", href: "/profile", icon: "user" },
  { label: "Recruiter inbox", href: "/inbox", icon: "mail" },
  { label: "Recruiter finder", href: "/recruiters", icon: "users" },
  { label: "Connections", href: "/connections", icon: "plug" },
];

export type MarketTrend = {
  week: string;
  demand: number;
  salary: number;
  sponsorship: number;
  remoteShare: number;
};

export const marketTrendData: MarketTrend[] = [
  { week: "Sep 1", demand: 58, salary: 148, sponsorship: 42, remoteShare: 61 },
  { week: "Sep 8", demand: 64, salary: 151, sponsorship: 44, remoteShare: 63 },
  { week: "Sep 15", demand: 61, salary: 153, sponsorship: 46, remoteShare: 60 },
  { week: "Sep 22", demand: 72, salary: 157, sponsorship: 49, remoteShare: 66 },
  { week: "Sep 29", demand: 78, salary: 161, sponsorship: 53, remoteShare: 68 },
];
